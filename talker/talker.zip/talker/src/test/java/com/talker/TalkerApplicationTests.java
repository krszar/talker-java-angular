package com.talker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TalkerApplicationTests {

	@Test
	void contextLoads() {
	}

}
